package com.clase4.clase4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase4Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase4Application.class, args);
	}

}
